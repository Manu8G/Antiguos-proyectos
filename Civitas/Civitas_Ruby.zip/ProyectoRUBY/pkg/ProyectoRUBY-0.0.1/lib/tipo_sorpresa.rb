# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module TipoSorpresa
    IR_CARCEL =:ir_carcel
    IR_CASILLA =:ir_casilla
    PAGAR_COBRAR =:pagar_cobrar
    POR_CASA_HOTEL =:por_casa_hotel
    POR_JUGADOR =:por_jugador 
    SALIR_CARCEL =:salir_carcel
end
