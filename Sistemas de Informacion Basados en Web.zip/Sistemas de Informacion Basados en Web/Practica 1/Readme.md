Esta pagina esta horientada a pasar un buen rato en momentos dificiles, puedes o entretenerte tu solo o con otra gente que este tambien pasandolo mal(quien sabe a lo mejor consigues nuevos amigos). 
Entre las diferentes diversiones estan:
    Cine solo: donde puedes ver diferentes peliculas con generos alegres y divertidos para animarte.
    Cine en grupo: donde puedes ver cine pero con una pestaña de chat alado para comentar con la gente que 
        este viendo esa pelicula aspectos de la misma.
    Monologos: donde podras ver monologos con un chat alado para comentarlos con las personas que lo esten viendo.
    Gatitos: ver gatitos siempre anima(se admiten otros animales adorables).
    Memes:un buen meme alegra a cualquiera
    Videos de risa: videos de risa.
    Meet: salas para hablar con personas desconocidas. Aqui ademas se puede usar un generador de temas para charlar.
    Videojuegos: jugar con gente random a juegos divertidos
    Musica triste: la musica triste tambien ayuda.

En elementos auxiliares tenemos una zona para crear salas privadas para jugar con tus amigos, los diferentes elementos aqui son:
    Cine: ver peliculas con tus amigos con un chat comun
    Monologo: ver un monologo con un chat comun
    Pelea de gatitos: esta modalidad consiste en que cada uno de los participantes busquen una imagen de un 
        gatito despues estas se juntaran y se hara una votacion para elegir la mejor. Aqui existe la posibilidad 
        de poner espectadores que puedan participar en la votacion.
    Pelea de memes: el mismo formato que pelea de gatitos pero con memes.
    Pelea de videos: el mismo formato que pelea de gatitos pero con videos de risa.
    Musica y amigos: aqui se crea una sala con musica para charlar tranquilamente con tus amigos, podeis crear 
        una lista de reproduccion conjunta y usar el generador de temas para sacar un tema de conversacion.
    Videojuegos: jugar con tus amigos a un mismo juego o crear un campeonato donde jugar diferentes juegos y 
        ver quien es el mejor.



