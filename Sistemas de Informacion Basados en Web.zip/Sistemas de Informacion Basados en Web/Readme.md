El apartado visual se realizo de manera rapida, no se buscaba un apartado visual bonito. 
El tema de la pagina web(La lloreria) surgio de la idea de un amigo, un sitio donde ir 
cuando estes trite a distraerte o conocer gente con la que jugar, ver peliculas o 
simplemente hablar.

Actualmente no tengo el codigo completo de esta actividad, tengo los diferentes apartados que hay que entregar en las practicas 1,2,3 y 5.
Subire este contenido faltante con la mayor brevedad posible.