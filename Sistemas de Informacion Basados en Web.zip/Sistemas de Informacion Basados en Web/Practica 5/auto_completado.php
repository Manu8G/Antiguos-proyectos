<html>
    <head>
        <title>Formulario de autocompletado.</title>
        <!-- Enlazar con el framework de AJAX -->
        <script src="linkdeajaxdeInternet"></script>
    </head>

    <body>
        <div class="container">
            <label>Introduce el evento</label>
            <input type="text" name="evento" id="evento" class="form-control" placeholder="Nombre del evento">

            <div id="listaEventos"></div>
        </div>
    </body>

    <script type ="text/javascript" scr="./script.js"></script>
</html>