<?php
    require_once "/home/manuelmesias/Practica3/vendor/autoload.php";
    $loader = new \Twig\Loader\FilesystemLoader('templates');
    $twig = new \Twig\Environment($loader);

	function startsWith($string, $query){
		return substr($string, 0, strlen($query))==$query;
	}
	//devuelve true si la cadena q le paso comienza por otra cadena
	//distinta
	$uri=$_SERVER['REQUEST_URI'];
	if(startsWith($uri, "/evento")){//en el caso de que sea evento pues evento
		include("scripts/evento.php");
	}else{//en otro caso cualquiera se pondra la portada
		echo $twig->render('portada.html', []);
	}

?>
