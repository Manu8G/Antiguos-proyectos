<?php
  function getEvento($idEv){
	$mysqli = new mysqli("localhost", "manuelmesias", "1234", "SIBW");
	//crea un objeto de mysqli(host, usuario, contraseña, base de datos)
    if($mysqli->connect_errno){
	echo ("Fallo al conectar: " . $mysqli->connect_error);
    }
    $res=$mysqli->query("SELECT nombre, hora FROM eventos WHERE id=" . $idEv);
    // hacemos get de los datos, esto es peligroso 'inyeccion de codigo'
    //https://websitebeaver.com/prepared-statements-in-php-mysqli-to-prevent-sql-injection
    $evento=array('nombre'=>'LA PELICULA DE TUS SUEÑOS', 'hora'=>'65.001');
    if($res->num_rows>0){
	$row = $res->fetch_assoc();
	$evento = array('nombre'=> $row['nombre'], 'hora'=>$row['hora']);
    }
    return $evento;
  }
?>
