var ChangeWimg=document.getElementById("comentarios_c");
var ChangeWzonai=document.getElementById("zona_i");
var ChangeWzonad=document.getElementById("zona_d");
var zona_come=document.getElementById("zona_come");
var comentarios=document.getElementById("comentarios");
var nombre=document.getElementById("nombre1");
var email=document.getElementById("email1");
var texto=document.getElementById("texto1");
function func1(){

    if(ChangeWzonai.className == "zona_i"){
        ChangeWzonai.className="zona_i_2";
        ChangeWzonad.className="zona_d_2";
        zona_come.style.display="none";

    }else{
        ChangeWzonai.className="zona_i";
        ChangeWzonad.className="zona_d";
        zona_come.style.display="inline";
    }
    
}

function aniade(data){
    var html = "<div id='comentario'><span>"+data.nombre1+"</span><br><span>"+data.email1+"</span><br><p>"+data.texto1+"</p><span>"+data.fecha1+"</span><br></div>"; 
    comentarios.insertAdjacentHTML('afterbegin', html);
}

var coment=[
    {"nombre1":"Joaquin", "email1":"JoaquinMaximoGoleador@correo.go.ugr.es.com", "texto1":"Estoy esperando ansioso esta parte!!","fecha1":"Wed Apr 07 2021 20:21:55 GMT+0200 (hora de verano de Europa central)"},
    {"nombre1":"Leonidas", "email1":"LeonidasDeJesus@correo.go.ugr.es.com", "texto1":"Estoy muy emocionado!!", "fecha1":"Wed Apr 07 2021 13:51:15 GMT+0200 (hora de verano de Europa central)"}
];    

for(var i=0; i<coment.length; i++){
    aniade(coment[i]); 
}

function func2(){
    var valido=comprueba_email(email.value);
    var bool=comprueba_campos();
    if(bool==true){
        if(valido==true){
            var addObj = {
                "nombre1": nombre.value,
                "email1": email.value,
                "texto1": texto.value,
                "fecha1": new Date(),
            };
            console.log(addObj);
            aniade(addObj);
        }else{
            alert('El correo electronico NO es valido');
        }
    }else{
        alert('Debe rellenar todos los campos');
    }
}
function comprueba_email(correo){
    var expReg= /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/;
    var valido=expReg.test(correo);
    return valido; 
}

function comprueba_campos(){
    if(nombre.value.length==0){
        return false;
    }else if(email.value.length==0){
        return false;
    }else if(texto.value.length==0){
        return false;
    }else{
        return true;
    }
}

function filtro(){
    let badwordsRegex=/pito|cola|micromachismo|puta|gilipollas|zorra|metalgreimon|puto|guarra|coronavirus/gi;
    texto.value=texto.value.replace(badwordsRegex, badword=>"*".repeat(badword.length));
}
/*
texto.addEventListener('keyup',(event)=>{
    let badwordsRegex=/pito|cola|tocarte|puta|gilipollas|zorra|metalgreimon|puto|guarra|coronavirus/gi;
    let compru=document.getElementById("texto1");
    let cambio=compru.replace(badwordsRegex, badword=>"*".repeat(badword.length));
    document.getElementById("texto1")=cambio;
});
*/
