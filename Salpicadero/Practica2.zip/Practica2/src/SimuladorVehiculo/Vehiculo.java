package SimuladorVehiculo;

import ControlAutomatico.CalcularVelocidad;
import ControlAutomatico.EstadoMotor;
import GUI.GUI;

/**
 *
 * @author Manu
 */

public class Vehiculo extends Thread{
    private double velocidad_mantenida;
    private double velocidad;
    private double revoluciones; 
    private double combustible;
    private EstadoMotor estado;    
    private static int MAXREV = 5000;
    private double distancia;
    private double rozamiento;
    private GUI interfaz;
    private CalcularVelocidad CV;
    private boolean apagar;
    private double RevolucionesTotales;
    private double r;
    
    public Vehiculo(GUI var, CalcularVelocidad aux){
        interfaz = var;
        CV = aux;
        velocidad = 0.0;
        revoluciones = 0.0;
        combustible = 100.0;
        estado = EstadoMotor.apagado;
        distancia = 0.0;
        rozamiento = 0.15;
        apagar = true;
        RevolucionesTotales = 0.0;
        aux.aniadeVehiculo(this);
        r = 100;
    }
    
    public double getRevoluciones(){
        return revoluciones;
    }
    
    public double getCombustible(){
        return combustible;
    }
    
    public double getDistancia(){
        return distancia;
    }
    
    public double getVelocidad(){
        return velocidad;
    }
    
    public double getVelocidadMantenida(){
        return velocidad_mantenida;
    }
    
    public EstadoMotor getEstadoMotor(){
        return estado;
    }
    
    public void setEstadoMotor(EstadoMotor e){
        estado = e;
    }
    
    public void setCombustible(){
        combustible = 100.0;
    }
    
    public void setVelocidadMantenida(double v){
        velocidad_mantenida = v;
    }
    
    public void repostar(){
        combustible = 100.0;
    }

    public void parar(){
        revoluciones = 0.0;
    }
    
    public void acelerar(){
        revoluciones += r;
        r = r * 1.05;
        
        if(MAXREV < revoluciones){
            revoluciones = MAXREV;
        }
        
        RevolucionesTotales += revoluciones;
    }
    
    public void reducir(){
        revoluciones -= 150.0;
        r = r * 0.95;
        
        if(revoluciones < 0){
            revoluciones = 0.0;
        }
        RevolucionesTotales += revoluciones;
    }
    
    public void arrancar(){
        estado = EstadoMotor.encendido;
        apagar = false;
        
        if (!this.isAlive()){
            this.start();
        }
    }
    
    public void pararMotor(){
        estado = EstadoMotor.apagado;        
        velocidad_mantenida = 0.0;
    }
    
    public void apagarHebra(){
        estado = EstadoMotor.apagado;
        apagar = true;
    }
    
    public double getRevolucionesTotales(){
        return RevolucionesTotales;
    }
    
    public void rozamiento(){
        revoluciones -= 50;
        
        if(revoluciones < 0){
            revoluciones = 0.0;
        }
    }
    
    
    @Override
    public void run(){
        while (!apagar){
            try{
                velocidad = CV.getVelocidad();
                
                if(velocidad < 0.0){
                    velocidad = 0.0;
                }
                
                distancia += velocidad * 0.1;
                combustible -= revoluciones * 0.00000005;
                
                if(combustible < 0.0){
                    combustible = 0.0;
                }
                
                Thread.sleep(1000);
                interfaz.refrescar();
            } catch (InterruptedException ex){}
        }
        
        this.rozamiento();
        interfaz.refrescar();
    }
}
