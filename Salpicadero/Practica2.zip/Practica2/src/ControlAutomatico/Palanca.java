package ControlAutomatico;

import SimuladorVehiculo.Vehiculo;

/**
 *
 * @author Manu
 */
public class Palanca{
    public ControlAutomatico CA;
    public EstadoPalanca estado;
    public Vehiculo vehiculo;
    
    public Palanca(){
        estado = EstadoPalanca.apagado;
    }
    
    public void addVehiculo(Vehiculo v){
        vehiculo = v;
    }
    
    public void setPosicion(EstadoPalanca aux){
        CA.cambiaEstado(aux);
        /*if(aux == EstadoPalanca.mantener && CA.getEstado() == EstadoPalanca.acelerar){
            vehiculo.setVelocidadMantenida(vehiculo.getVelocidad());
            CA.cambiaEstado(aux);
            estado = aux;
        } else if(aux == EstadoPalanca.reiniciar && CA.getEstado() == EstadoPalanca.apagado && vehiculo.getVelocidadMantenida() > 0.0){
            CA.cambiaEstado(aux);
            estado = aux;
        } else if(estado == EstadoPalanca.apagado && CA.getEstado() != EstadoPalanca.acelerar){
            CA.cambiaEstado(aux);
            estado = aux;
        } else if(aux == EstadoPalanca.acelerar){
            CA.cambiaEstado(aux);
            estado = aux;
        }*/
    }
    
    public void cambiarEstado(EstadoPalanca aux){
        estado = aux;
    }
    
    public EstadoPalanca getEstado(){
        return estado;
    }
}
