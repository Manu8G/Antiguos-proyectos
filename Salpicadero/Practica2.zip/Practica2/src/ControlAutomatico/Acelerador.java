package ControlAutomatico;

import SimuladorVehiculo.Vehiculo;

/**
 *
 * @author Manu
 */
public class Acelerador{
    private Vehiculo vehiculo;
    
    public Acelerador(Vehiculo otro){
        vehiculo = otro;
    }
    
    void acelerar(){
        vehiculo.acelerar();
    }
    
    void desacelerar(){
        vehiculo.reducir();
    }
}
