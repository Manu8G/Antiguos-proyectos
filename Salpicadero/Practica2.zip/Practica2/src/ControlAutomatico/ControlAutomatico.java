package ControlAutomatico;

/**
 *
 * @author Manu
 */
public class ControlAutomatico extends Thread{

    public double CONSTANTE = 100;
    public Acelerador acelerador;
    public CalcularVelocidad CV;
    public EstadoPalanca estado;
    public EstadoPalanca historico;
    public boolean apagar;
    
    public ControlAutomatico(Acelerador aux, CalcularVelocidad var){
        acelerador = aux;
        CV = var;
        estado = EstadoPalanca.apagado;
        historico = EstadoPalanca.apagado;
        apagar = true;
    }
    
    public EstadoPalanca getEstado(){
        return estado;
    }
    
    public void cambiaEstado(EstadoPalanca cambio){
        historico = estado;
        estado = cambio;
    }
}
