package ControlAutomatico;

import SimuladorVehiculo.Vehiculo;

/**
 *
 * @author Manu
 */
public class CalcularVelocidad{
    static double CONSTANTE = (60.0/100.0);
    double velocidad; 
    static double RADIO = 0.012;
    static double PI = 3.14;
    public Vehiculo vehiculo;
    
    
    public CalcularVelocidad(){
        velocidad = 0.0;
    }
    
    public void aniadeVehiculo(Vehiculo aux){
        vehiculo = aux;
    }
    
    public double getVelocidad(){
        velocidad = 2 * PI * RADIO * vehiculo.getRevoluciones() * CONSTANTE;
        return velocidad;
    }
}
