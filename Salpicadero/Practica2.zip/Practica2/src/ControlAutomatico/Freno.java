package ControlAutomatico;

import SimuladorVehiculo.Vehiculo;

/**
 *
 * @author Manu
 */
public class Freno{
    public Vehiculo vehiculo;
    private ControlAutomatico controlAutomatico;
    public EstadoPalanca estado;
    
    public Freno(Vehiculo vehiculo, final ControlAutomatico controlAutomatico){
        this.vehiculo = vehiculo;
        this.controlAutomatico = controlAutomatico;
        estado = EstadoPalanca.apagado;
    }
}
