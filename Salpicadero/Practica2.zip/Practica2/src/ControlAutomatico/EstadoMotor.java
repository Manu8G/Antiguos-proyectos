package ControlAutomatico;

/**
 *
 * @author Manu
 */
public enum EstadoMotor{
    encendido, apagado, acelerando, frenando, manteniendo
}
