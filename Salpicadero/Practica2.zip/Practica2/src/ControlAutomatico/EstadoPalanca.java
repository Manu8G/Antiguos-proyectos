package ControlAutomatico;

/**
 *
 * @author Manu
 */
public enum EstadoPalanca{
    acelerar, apagado, reiniciar, mantener
}
