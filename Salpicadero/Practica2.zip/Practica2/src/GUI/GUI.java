package GUI;

import ControlAutomatico.Acelerador;
import ControlAutomatico.CalcularVelocidad;
import ControlAutomatico.ControlAutomatico;
import ControlAutomatico.EstadoMotor;
import ControlAutomatico.EstadoPalanca;
import ControlAutomatico.Palanca;
import SimuladorVehiculo.Vehiculo;
import java.awt.BorderLayout;
import java.awt.Color;

/**
 *
 * @author alvaro149
 */
public class GUI extends javax.swing.JApplet {
    private PanelControlAutomatico pca;
    private PanelVelocimetro vel;
    private PanelPalanca palanca;
    private PanelAcelerador acelerador;
    private PanelRevisiones r;
    private EstadoMotor estado;
    private Palanca pal;
    private CalcularVelocidad cv;
    private Vehiculo vehiculo;
    private ControlAutomatico ca;
    private Acelerador ace;
    /**
     * Initializes the applet GUI
     */
    private void iniciarVehiculo(){
        vehiculo = new Vehiculo(this, cv);
    }
    
    @Override
    public void init() {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        setBackground(Color.WHITE);
        initComponents();
        cv = new CalcularVelocidad();
        iniciarVehiculo();
        
        pal = new Palanca();
        pca = new PanelControlAutomatico(vehiculo, pal);
        pca.setSize(400, 400);
        pca.setLocation(5, 5);
        panelControl.add(pca, BorderLayout.CENTER);
        
        ace = new Acelerador(vehiculo);
        ca = new ControlAutomatico(ace, cv);
                                        
        vel = new PanelVelocimetro(vehiculo);
        vel.setSize(400,300);
        vel.setLocation(5, 5);
        panelVelocimetro.add(vel, BorderLayout.CENTER);
                    
        palanca = new PanelPalanca(pca, vehiculo, pal, ca);
        palanca.setSize(400, 400);
        palanca.setLocation(5, 5);
        panelPalanca.add(palanca, BorderLayout.CENTER);
                    
        acelerador = new PanelAcelerador(vehiculo);
        acelerador.setSize(400,600);
        acelerador.setLocation(5, 5);
        panelAcelerador.add(acelerador, BorderLayout.CENTER);
                    
        r = new PanelRevisiones(vehiculo);
        r.setSize(500, 500);
        r.setLocation(5, 5);
        panelRevisiones.add(r, BorderLayout.CENTER);
                    
        pal.addVehiculo(vehiculo);
        pintar();
        /* Create and display the applet */
        /*try {
            java.awt.EventQueue.invokeAndWait(new Runnable() {
                public void run() {
                    
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }*/
    }
    
    
    public void refrescar(){
        if(vehiculo.getEstadoMotor() == EstadoMotor.acelerando){
            vehiculo.acelerar();
        } else if(vehiculo.getEstadoMotor() == EstadoMotor.frenando){
            vehiculo.reducir();
        } else if(vehiculo.getEstadoMotor() == EstadoMotor.encendido){
            vehiculo.rozamiento();
        } else if((vehiculo.getEstadoMotor() == EstadoMotor.encendido) && (pal.getEstado() == EstadoPalanca.mantener)){
            
        } else if((pal.getEstado() == EstadoPalanca.reiniciar) && (vehiculo.getEstadoMotor() == EstadoMotor.manteniendo)){
            if(vehiculo.getVelocidadMantenida() < vehiculo.getVelocidad()){
                vehiculo.reducir();
            } else if(vehiculo.getVelocidadMantenida() > vehiculo.getVelocidad()){
                vehiculo.acelerar();
            }
        }
        
        pca.refrescar();
        vel.refrescar();
        palanca.refrescar();
        acelerador.refrescar();
        r.refrescar();
    }
    
    public void pintar(){
        panelAcelerador.setBackground(Color.white);
        panelControl.setBackground(Color.white);
        panelPalanca.setBackground(Color.white);
        panelRevisiones.setBackground(Color.white);
        panelVelocimetro.setBackground(Color.white);
    }
    /**
     * This method is called from within the init() method to initialize the
     * form. WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelControl = new javax.swing.JPanel();
        panelVelocimetro = new javax.swing.JPanel();
        panelPalanca = new javax.swing.JPanel();
        panelAcelerador = new javax.swing.JPanel();
        panelRevisiones = new javax.swing.JPanel();

        javax.swing.GroupLayout panelControlLayout = new javax.swing.GroupLayout(panelControl);
        panelControl.setLayout(panelControlLayout);
        panelControlLayout.setHorizontalGroup(
            panelControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 349, Short.MAX_VALUE)
        );
        panelControlLayout.setVerticalGroup(
            panelControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 341, Short.MAX_VALUE)
        );

        panelVelocimetro.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout panelVelocimetroLayout = new javax.swing.GroupLayout(panelVelocimetro);
        panelVelocimetro.setLayout(panelVelocimetroLayout);
        panelVelocimetroLayout.setHorizontalGroup(
            panelVelocimetroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 381, Short.MAX_VALUE)
        );
        panelVelocimetroLayout.setVerticalGroup(
            panelVelocimetroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelPalancaLayout = new javax.swing.GroupLayout(panelPalanca);
        panelPalanca.setLayout(panelPalancaLayout);
        panelPalancaLayout.setHorizontalGroup(
            panelPalancaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 272, Short.MAX_VALUE)
        );
        panelPalancaLayout.setVerticalGroup(
            panelPalancaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 290, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelAceleradorLayout = new javax.swing.GroupLayout(panelAcelerador);
        panelAcelerador.setLayout(panelAceleradorLayout);
        panelAceleradorLayout.setHorizontalGroup(
            panelAceleradorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 199, Short.MAX_VALUE)
        );
        panelAceleradorLayout.setVerticalGroup(
            panelAceleradorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelRevisionesLayout = new javax.swing.GroupLayout(panelRevisiones);
        panelRevisiones.setLayout(panelRevisionesLayout);
        panelRevisionesLayout.setHorizontalGroup(
            panelRevisionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        panelRevisionesLayout.setVerticalGroup(
            panelRevisionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 313, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addComponent(panelVelocimetro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 92, Short.MAX_VALUE)
                        .addComponent(panelControl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(panelRevisiones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(panelAcelerador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(panelPalanca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(38, 38, 38))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panelVelocimetro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelControl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelAcelerador, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(panelPalanca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(panelRevisiones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 34, Short.MAX_VALUE)))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel panelAcelerador;
    private javax.swing.JPanel panelControl;
    private javax.swing.JPanel panelPalanca;
    private javax.swing.JPanel panelRevisiones;
    private javax.swing.JPanel panelVelocimetro;
    // End of variables declaration//GEN-END:variables
}
