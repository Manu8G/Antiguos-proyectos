/**
   @file circulomedio.cpp
   @brief Calcula c�rculo con centro en medio de dos c�rculos y radio la mitad de la distancia
   @warning M�dulo no definitivo (creado para ser modificado)

// si quiere utilizar la funcion to_string(), recuerde agregar -std=c++0x (o -std=c++11) a las opciones del compilador

**/

#include <iostream>
#include <cmath> 
#include <string>

using namespace std;

const double PI = 3.14159265;
class Punto {
private:
    double x; // coordenada x del punto
    double y; // coordenada y del punto

public:
    Punto(); //constructor. Pone a 0 las dos coordenadas
    Punto(double px, double py); 
    double getX(); 
    double getY(); 
    void setX(double px); 
    void setY(double py); 
    string toString(); 
    double distancia(Punto p2); 
    Punto puntoMedio(Punto p2); 
};

Punto::Punto():x(0),y(0) {
}

Punto::Punto(double px, double py):x(px),y(py) {
}

double Punto::getX() {
	return x;
}

double Punto::getY() {
	return y;
}

void Punto::setX(double px) {
	x = px;
}

void Punto::setY(double py) {
	y = py;
}

string Punto::toString() {
 // devuelve un string con el formato (x,y)
}

double Punto::distancia(Punto p2){
	
	double distancia=0.0;
	
	distancia=(pow(p2.getX()-x,2)+pow(p2.getY()-y,2));	

	distancia=sqrt(distancia);
	
	return distancia;	

}


Punto Punto::puntoMedio(Punto p2){
	
	Punto p3;
	double suma;

	suma=(x+p2.getX())/2;

	p3.setX(suma);

	suma=(y+p2.getY())/2;

	p3.setY(suma);

	return p3;

}


class Circulo {
private:
    Punto centro; // Centro del c�rculo
    double radio; // radio del c�rculo

public:
    Circulo(); // Constructor: Pone a 0 el punto y el radio
    Circulo(Punto centro, double rradio); // Constructor: Inicializa el c�rculo con un centro y un radio
    void set(Punto centro, double rradio); // Asigna el centro y el radio a un circulo
    Punto getCentro(); 
    double getRadio(); 
    string toString(); // devuelve el contenido del circulo como un string
    double area(); // Devuelve el �rea de un c�rculo
    double radionuevo (Circulo c2);
    bool interior (Punto p); // true si p est� contenido en el c�rculo
};

Circulo::Circulo():centro(0,0), radio(0) {
}

Circulo::Circulo(Punto p, double rradio):centro(p),radio(rradio) {
}

void Circulo::set(Punto p, double rradio) {
	
	radio = rradio;
	centro = p;

}


Punto Circulo::getCentro()  {
	
	return centro;

}

double Circulo::getRadio()  {

	return radio;

}

/*string Circulo::toString() {
}
*/

double Circulo::area() {

    return PI * radio * radio;

}

double Circulo::radionuevo (Circulo c2){		

	double radio3;

	radio3=(c2.getRadio()-radio)/2;

	return radio3;

}


//Comprueba si un punto es interior al c�rculo
bool Circulo::interior (Punto p){
}


int main(){

	double radio;
	double X;
	double Y;
	
	
	cout << "Introduzca el radio: ";
	cin >> radio;
	cout << "Introduzca la coordenada X: ";
	cin >> X;
	cout << "Introduzca la coordenada Y: ";
	cin >> Y;

	Punto p1(X,Y);
	Circulo c1( p1, radio);

	cout << "Introduzca el radio: ";
	cin >> radio;
	cout << "Introduzca la coordenada X: ";
	cin >> X;
	cout << "Introduzca la coordenada Y: ";
	cin >> Y;

	Punto p2(X,Y);
	Circulo c2(p2, radio);

	Punto p3;
	
	p3=p1.puntoMedio(p2);	 

	radio=c1.radionuevo(c2);
	Circulo c3(p3, radio); 

	// mostrar resultados
    
   
	cout << "\nEste es el primer circulo\t" << p1.getX() << "\n" << p1.getY() << "\n" << "\nEste es el radio\t"<< c1.getRadio();	
	
	cout << "\nEste es el segundo circulo\t" << p2.getX() << "\n" << p2.getY() << "\n" << "\nEste es el radio\t" << c2.getRadio();
 
	cout << "\nEste es el tercer circulo\t" << p3.getX() << "\n" << p3.getY() << "\n" << "\nEste es el radio\t" << c3.getRadio();
    
	cout << "\nEsta es la distancia entre los dos centros\t" << p1.distancia(p2);

	cout << "\nEsta es el area del circulo 1\t" << c1.area();
	cout << "\nEsta es el area del circulo 2\t" << c2.area();	
	cout << "\nEsta es el area del circulo 3\t\n" << c3.area();
}

/* Fin: circulomedio.cpp */
