#include <iostream>
#include <cmath> 
#include "punto.h"
#include "circulo.h"


using namespace std;

const double PI = 3.14159265;

int main(){

	double radio;
	double X;
	double Y;
	
	
	cout << "Introduzca el radio: ";
	cin >> radio;
	cout << "Introduzca la coordenada X: ";
	cin >> X;
	cout << "Introduzca la coordenada Y: ";
	cin >> Y;

	Punto p1(X,Y);
	Circulo c1( p1, radio);

	cout << "Introduzca el radio: ";
	cin >> radio;
	cout << "Introduzca la coordenada X: ";
	cin >> X;
	cout << "Introduzca la coordenada Y: ";
	cin >> Y;

	Punto p2(X,Y);
	Circulo c2(p2, radio);

	Punto p3;
	
	p3=p1.puntoMedio(p2);	 

	radio=c1.radionuevo(c2);
	Circulo c3(p3, radio); 

	// mostrar resultados
    
   
	cout << "\nEste es el primer circulo\t" << p1.getX() << "\n" << p1.getY() << "\n" << "\nEste es el radio\t"<< c1.getRadio();	
	
	cout << "\nEste es el segundo circulo\t" << p2.getX() << "\n" << p2.getY() << "\n" << "\nEste es el radio\t" << c2.getRadio();
 
	cout << "\nEste es el tercer circulo\t" << p3.getX() << "\n" << p3.getY() << "\n" << "\nEste es el radio\t" << c3.getRadio();
    
	cout << "\nEsta es la distancia entre los dos centros\t" << p1.distancia(p2);

	cout << "\nEsta es el area del circulo 1\t" << c1.area();
	cout << "\nEsta es el area del circulo 2\t" << c2.area();	
	cout << "\nEsta es el area del circulo 3\t\n" << c3.area();
}

/* Fin: circulomedio.cpp */
