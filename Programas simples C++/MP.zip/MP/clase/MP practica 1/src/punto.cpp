#include <iostream>
#include <cmath> 

#include "punto.h"


using namespace std;

const double PI = 3.14159265;

Punto::Punto():x(0),y(0) {
}

Punto::Punto(double px, double py):x(px),y(py) {
}

double Punto::getX() {
	return x;
}

double Punto::getY() {
	return y;
}

void Punto::setX(double px) {
	x = px;
}

void Punto::setY(double py) {
	y = py;
}

/*
string Punto::toString() {
 // devuelve un string con el formato (x,y)
}
*/

double Punto::distancia(Punto p2){
	
	double distancia=0.0;
	
	distancia=(pow(p2.getX()-x,2)+pow(p2.getY()-y,2));	

	distancia=sqrt(distancia);
	
	return distancia;	

}


Punto Punto::puntoMedio(Punto p2){
	
	Punto p3;
	double suma;

	suma=(x+p2.getX())/2;

	p3.setX(suma);

	suma=(y+p2.getY())/2;

	p3.setY(suma);

	return p3;

}
