#ifndef _PUNTO_H
#define _PUNTO_H

class Punto {
private:
    double x; // coordenada x del punto
    double y; // coordenada y del punto

public:
    Punto(); //constructor. Pone a 0 las dos coordenadas
    Punto(double px, double py); 
    double getX(); 
    double getY(); 
    void setX(double px); 
    void setY(double py); 

/*    string toString(); 
*/
    double distancia(Punto p2); 
    Punto puntoMedio(Punto p2); 
};

#endif
