#ifndef _VIAJE_H
#define _VIAJE_H

#include<iostream>
#include<string>

using namespace std;


const int MAX=100;

void mejorTrayecto(int m[MAX][MAX], int n, int utils, int v3[] );

long long costeTrayecto(int v[], int m[MAX][MAX], int utils);

void vecinoMasCercano(int m[MAX][MAX], int utils, long long & coste, int v[]);

string trayectoToString(int v[], int utils);

#endif
