#include<iostream>
#include<string>

#include"viaje.h"

using namespace std;

int main(){

	int matriz[MAX][MAX];
	int v_solucion[MAX];
	int v_barato[MAX];
	int clientes=0;
	int ciudad_inicio=0;
	int ciudad_barata=0;
	long long dinero=0;
	const int MAX_DIST=1000;
	int mejor_trayecto[MAX];
	int mejor_precio=0;

	cout << "\nNumero de clientes a visitar:\n ";
	cin >> clientes;

	cout << "\nIntroduzca la matriz por filas y teniendo en cuenta que la diagonal es cero: \n  ";
	for(int i=0; i<clientes; i++){

		for(int j=0; j<clientes; j++){

			if(i!=j){
			

				cin >> dinero;			
			
				if(dinero<=0 || dinero>MAX_DIST){	
				
					//cout << "Dato erroneo, introduzca el dinero entre 0 y mil: ";	

					cin >> dinero;

					while(dinero<=0 || dinero>MAX_DIST){

						cin >> dinero;

					}

					matriz[i][j]=dinero;

				}else{

					matriz[i][j]=dinero;

				}

			}else{

				matriz[i][j]=0;
			
			}
		
		}

	}

	mejorTrayecto(matriz, ciudad_inicio, clientes, v_solucion);
	
	cout << "\nEl mejor trayecto seria: \n";

	cout << trayectoToString(v_solucion, clientes);

	cout << "\n El coste del trayecto comenzando en la primera ciudad seria";

	cout << costeTrayecto( v_solucion, matriz, clientes);

	vecinoMasCercano( matriz, clientes, dinero, mejor_trayecto);

	cout << "\nEl mejor trayecto posible seria:\n ";

	cout << trayectoToString(mejor_trayecto, clientes);

	cout << "\nEl precio del viaje perfecto seria:\n ";

	cout << dinero << "\n";




}
