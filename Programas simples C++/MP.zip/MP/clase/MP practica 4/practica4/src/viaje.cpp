#include<iostream>
#include<string>

using namespace std;


const int MAX=100;

void mejorTrayecto(int m[MAX][MAX], int n, int utils, int v3[] ){ 	//Recibe matriz ciudad de inicio y tamaño(utils) y ciudad de inicio(n), y devuelve v3 con el mejor trayecto

	bool v2[MAX]={0};
	int mas_barato=1001;
	int nuevo_precio=1001;
	int posicion=0;
	int cont=0;
	int i=n;

	v2[n]=true;
	v3[0]=n;

	while(cont<utils){

		for(int j=0; j<utils; j++){

			nuevo_precio=m[i][j];

			if(v2[j]!=true && nuevo_precio<mas_barato){
				
				if(j!=n){

					mas_barato=nuevo_precio;	
					posicion=j;

				}

			}
		
		}
		
		cont++;
		mas_barato=1001;
		nuevo_precio=1001;
		v2[posicion]=true;
		v3[cont]=posicion;
		i=posicion;
		n=posicion;

	}

}

long long costeTrayecto(int v[], int m[MAX][MAX], int utils){		//Recibe vector con el trayecto final , matriz y utils del vector, y devuelve el coste del trayecto anterior

	long long coste=0;
	int ciudad=0;
	int j=v[0];

	for(int i=1; i<utils; i++){

		ciudad=v[i];
		coste = coste + m[j][ciudad];
		j=ciudad;

	}

	j=v[0];

	coste = coste + m[ciudad][j];

	return coste;

}

void vecinoMasCercano(int m[MAX][MAX], int utils, long long & coste, int v[]){	//Le llega la matriz y devuelve el trayecto, la ciudad de inicio y su coste

	int v_nuevo[MAX];
	long long coste_nuevo=99999999;

	coste=999999;

	for(int i=0; i<utils; i++){

		mejorTrayecto(m, i, utils, v_nuevo);
		coste_nuevo=costeTrayecto(v_nuevo, m, utils);

		if(coste_nuevo<coste){

			for(int j=0; j<utils; j++){

				v[j]=v_nuevo[j];

			}

			coste=coste_nuevo;

		}
	


	}	


}

string trayectoToString(int v[], int utils){	//Le llega el vector solucion y su utils, y devuelve el string con los numeros en orden		

	string rta="";

	for(int i=0; i<utils; i++){

		rta = rta + "\t" + to_string(v[i]); 
	
	}

	return rta;

}

