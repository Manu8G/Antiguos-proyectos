#include<iostream> 

using namespace std;

int * PosMayor (int *pv, int izda, int dcha){

	int valor=0;
	int *p;
	
	*p=pv[izda];

	for(int i=izda; i<dcha; i++){

		valor=pv[i];
		
		if(*p>valor){

			*p=valor;

		}	


	}

	return p;

}


int main(){

	const int TOPE=100;
	int vector[TOPE];
	int utils=0;
	int menor=0;
	int mayor=0;
	int *p;
	int valor;
	int *solucion;

	*p=vector[];

	cout << "\nIntroduzca el numero de datos: ";
	cin >> utils;

	cout << "\nDato menor: ";
	cin >> menor;	

	cout << "\nDato mayor: ";
	cin >> mayor;

	cout << "\nIntroduzca los datos miembro del vector: ";

	for(int i=0; i<utils; i++){

		cin >> valor;
		p[i]=valor;

	}

	
	*solucion=PosMayor(*p, menor, mayor);


	cout << *solucion;

}
