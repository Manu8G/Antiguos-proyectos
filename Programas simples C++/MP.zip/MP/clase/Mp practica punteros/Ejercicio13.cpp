#include<iostream>

using namespace std;

void encadenar_cadena(char * ptr1, const char * ptr2){

	char letra=*ptr2;
	int cont=0;
	int cont2=4;
	

	while(letra!='\0'){
		
			*(ptr1+cont2)=*(ptr2+cont);
			letra=*(ptr2+cont);
			cont++;
			cont2++;
	}

	*(ptr1+cont2)='\0';

}


int main(){


	//char *ptruno="hola";
	char ptruno[15]="hola";
	char *ptrdos="adios";
	int cont=0;

	encadenar_cadena(ptruno, ptrdos);

	while(*(ptruno+cont)!='\0'){

		cout << "\n" << *(ptruno+cont);
		cont++;
		
	}


}
