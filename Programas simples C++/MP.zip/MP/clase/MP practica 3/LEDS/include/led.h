#ifndef _LED_H
#define _LED_H

#include<iostream>
#include<string>

using namespace std;

void encenderLed( bool v[], int MAX, int i);


void apagarLed( bool v[], int MAX, int i);

void cambiaLeds(char v[], int a[], int MAX, int utils);

string toString( bool v[], int MAX);

#endif

