#include<iostream>
#include<string>
#include"led.h"

using namespace std;


void encenderLed( bool v[], int MAX, int i){

	v[i]=true;

}


void apagarLed( bool v[], int MAX, int i){

	v[i]=false;

}


void cambiaLeds(char v[], int a[], int MAX, int utils){

	int variable;

	for(int i=0; i<MAX; i++){
		
		variable=a[i];
		
		if(v[variable]==true){

			v[variable]=false;

		}else{
	
			v[variable]=true;

		}	

	}



}


string toString( bool v[], int MAX){

	string rta="";

	for(int i=0; i<MAX; i++){

		rta = rta + to_string(v[i]);

	}
	
	return rta;
	
}


