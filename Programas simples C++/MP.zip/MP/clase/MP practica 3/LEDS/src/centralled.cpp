#include<iostream>
#include<string>
#include"led.h"

using namespace std;

int main(){


	const int MAX=100;
	bool tiraled[MAX]={0};	
	double dos=2.0;	
	int variable=0;

	cout << "\nEstado de la cadena:\n";
	
	cout << "\n" << toString(tiraled,MAX);

	cout << "\n--------------------------------------\n";

	for(int a=0; a<MAX; a++){
	
		if(a/dos == variable){
		
			encenderLed(tiraled,MAX,a);
			variable++;
		}


	}
	
	cout << "\nEstado de la cadena tras encender los pares\n";

	cout << "\n" << toString(tiraled,MAX);
 
	cout << "\n--------------------------------------\n";

	variable=0;

	for(int u=0; u<MAX; u++){
	
		if(u/dos ==variable){
		
			apagarLed(tiraled,MAX,u);
			variable++;
		}


	}
	
	cout << "\nEstado de la cadena tras apagar los pares\n:";
	
	cout << "\n" << toString(tiraled,MAX);

	cout << "\n";

	return(0);
	
}





