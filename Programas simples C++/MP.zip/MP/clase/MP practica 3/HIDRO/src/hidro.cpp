#include<iostream>
#include "hidro.h"

using namespace std;


bool esletra(char letra){

	bool variable=false;

	if((letra>='A' && letra<='Z') || (letra>='a' && letra<='z')){

		variable=true;

	}

	return variable;

}

bool comienzaPalabra(char v[], int MAX, int i){


	bool variable=false;

	if(i<MAX && i>0){	

		if(v[i-1]==' ' && esletra(v[i])){
	
			variable=true;	

		}
	
	}
	
	if(i==0 && esletra(v[i])){

		variable=true;

	}

	return variable;

}



bool terminaPalabra(char v[], int MAX, int i){

	bool variable=false;

	if(i+1<MAX){

	
		if(v[i+1]==' ' && esletra(v[i])){
		
			variable=true;	

		}

	}

	if(i+1==MAX && v[i+1]=='#' && esletra(v[i])){

		variable=true;

	}

		return variable;

}


void descifra(char v[], int MAX, char vector2[], int & utils){

	for(int i=0; i<MAX; i++){

		if((comienzaPalabra( v, MAX, i) || terminaPalabra(v,MAX,i))){

			vector2[utils]=v[i];
			utils++;

		}
			
	}

}


string toString(char v[], int MAX){

	string rta="";
	
	for(int i=0; i<MAX;i++){

		rta = rta + v[i];

	}

	return rta;

}

