#include<iostream>
#include<string>
#include"hidro.h"

using namespace std;

int main(){

	const int MAXIMO=100;
	char vector[MAXIMO];
	int utils=0;
	char TERMINADOR='#';
	string variable;
	char letra;
	char vector_final[MAXIMO];
	int utils2=0;

	cout << "\nIntroduzca la cadena de caracteres: \n";	
	
		letra=cin.get();

	while(utils<MAXIMO && letra!=TERMINADOR){

		
		vector[utils]=letra;
		letra=cin.get();
		utils++;
	};
	
	cout << toString(vector,utils) << endl;
	descifra(vector,utils, vector_final, utils2);
	variable=toString(vector_final,utils2);

	cout << variable;

}


