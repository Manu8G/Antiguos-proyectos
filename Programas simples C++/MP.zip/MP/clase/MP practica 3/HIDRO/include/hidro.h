#ifndef _HIDRO_H
#define _HIDRO_H

#include<iostream>
#include<string>

using namespace std;

bool esletra(char letra);

bool comienzaPalabra(char v[], int MAX, int i);

bool terminaPalabra(char v[], int MAX, int i);


void descifra(char v[], int MAX, char vector2[], int & utils);

string toString(char v[], int MAX);

#endif
