#include <iostream>
#include <cmath>
using namespace std;

struct Punto2D {

float x;
float y;

};


void Redimensiona ( Punto2D * &vector, int &TAM ){



Punto2D *vector_redimensionado = 0;
int cap = TAM+1;
vector_redimensionado = new Punto2D[cap];


for(int i = 0; i< TAM; i++)
	vector_redimensionado[i] = vector[i];

delete[] vector;

vector = vector_redimensionado;
TAM = cap;
}



float CalculaDistanciaCentro( float posicionX, float posicionY){

	float distancia;
	//Sabemos que el Centro es (10,10)

	distancia = sqrt( ((10 - posicionY)*(10 - posicionY)) + ((10 - posicionX)*(10 - posicionX)) );
	
	return distancia;
}



Punto2D *DentroCircunferencia( Punto2D *vector, int &TAM ){

	int cap = 1;
	int j = 0;
	float radio = 1.5;

	Punto2D *vector_dentro_circulo;
	vector_dentro_circulo = new Punto2D [cap];


	for(int i = 0; i< TAM; i++){
		if( CalculaDistanciaCentro(vector[i].x , vector[i].y) < radio){
			vector_dentro_circulo[j].x = vector[i].x;
			vector_dentro_circulo[j].y = vector[i].y;
			Redimensiona(vector_dentro_circulo, cap);
			j++;
		}
	}
	
	TAM = cap;
		

	return vector_dentro_circulo;
	


}


int main(){

int numero_puntos;

cout << "\nIntroduzca el número de puntos: \n";
cin >> numero_puntos;


Punto2D *vector_struct = 0;
vector_struct = new Punto2D [numero_puntos];

//Rellenamos el vector con los puntos

	for(int i = 0; i< numero_puntos; i++){
		cin >> vector_struct[i].x;
		cin >> vector_struct[i].y;
	}


Punto2D *vector_dentro = 0;

vector_dentro = DentroCircunferencia( vector_struct, numero_puntos);

cout << "\nLos puntos que se encuentran dentro del círculo son: ";

	for(int j = 0; j< numero_puntos-1; j++)
		cout << "\n " << vector_dentro[j].x << "\t" << vector_dentro[j].y;

cout << "\n";


return 0;
} 
