#include<iostream>

using namespace std;

void Redimensiona(int * & p, int & capacidad, int tipo){		//Cuando paso *p se pasa el contenido de p pero no donde apunta si hacemos & si pasa el contenido

	int *q;
	int tam=capacidad;

	if(tipo==1){

		capacidad++;

	}else if(tipo==2){

		capacidad+=3;

	}else{

		capacidad=(capacidad+1)*2;

	}

	q= new int [capacidad];
	

	for(int i=0; i<tam;i++){

		q[i]=p[i];

	}
	
	if(p!=0){
	
	delete [] p;

	}

	p=q;

	/*
		switch(tipo){

			case 1 :

				capacidad++;

			case 2:

				capacidad+=TAM_BLOQUE;


			case 3:

				capacidad=(capacidad+1)*2;

			default:

				cout << "ERROR";
				exit(1);

		}

	*/

}

int * obtenerSegmento(int * p, int tam, int & cont){

	int * q=0;
	int tipo=1;

	for(int i=0; i<tam; i++){

		if(i%2!=0){
			
		Redimensiona(q, cont, tipo);	
		q[cont-1]=i;

		}
		
	}
	
	return q;

}

int main(){

	int TERMINADOR=-1;
	int numero=0;
	int capacidad=3;
	int cont=0;
	int *p;
	int tipo=1;
	int capacidad2=0;
	int * t;

	p=new int [capacidad];

	cin >> numero;

	do{
		
		if(cont>=capacidad){
			
			cout << "\nIntroduzca el tipo de modificacion que quiere (1= aumenta en uno la capacidad, 2= aumento un bloque de tres el vector, 3=duplica el tamaño del vector)";
			cin >> tipo;
	
			Redimensiona(p, capacidad, tipo );

		}
		
		p[cont]=numero;
		cin >> numero;
		cont++;

	}while(numero!=TERMINADOR);
	

	for(int i=0; i<cont; i++){

		cout << "\n" << p[i];

	}
	t=obtenerSegmento(p, capacidad, capacidad2);
	
	cout << "\n\n\n";

	for(int j=0; j<capacidad2; j++){

		cout << "\n" << t[j];

	}

	delete [] p;
	delete [] t;

	cout << "\n";

}
