#include<iostream>

using namespace std;

void limpiar(char * * m, int utils ){ //rellena la matriz con todo puntos

	for(int i=0; i<utils; i++){
	
		for(int j=0; j<utils; j++){

				m[i][j]='.';
		
		}

	}

}

void dibujarcuadrado(char **m, int x, int y, int longitud, int utils){  //posicion y rellena en la longitud

	int uno=x+longitud;
	int dos=y+longitud;

	if(uno>=utils){

		uno=utils;

	}
	if(dos>=utils){

		dos=utils;

	}

	

	for(int i=x; i<uno; i++){

		for(int j=y; j<dos; j++){

				m[i][j]='*';

		}

	}

}

void rotar(char * * & m, int utils){

	char * * m2;

	m2=new char *[utils];

	for(int g=0; g<utils; g++){

		m2[g]=new char [utils];

	}


	for(int i=0; i<utils; i++){

		for(int j=0; j<utils; j++){	
	

			m2[j][i]=m[i][j];	

		}

	}	

	for(int t=0;t<utils; t++){
		
		delete[] m[t];

	}	
	
	delete[] m;

	m=m2;

	/*for(int i=0; i<utils; i++){

		for(int j=0; j<utils; j++){	

			m[i][j]=m2[i][j];	

		}

	}*/


}


void imprimir(char * * m, int utils){

	int cont=0;

	for(int i=0; i<utils; i++){
	
		for(int j=0; j<utils; j++){

				if(cont%utils==0){

					cout << "\n";

				}

				cout << " " << m[i][j] <<" ";
		
				cont++;

		}

	}

	cout << "\n";

}



int main(){

	char * * m;
	int filas=1;
	int columnas=1;
	int tam=0;
	int x=0;
	int y=0;
	int longitud=0;

	cout << "\nDame un tamaño para una matriz cuadrada ";
	cin >> filas;

	columnas=filas;

	m=new char * [filas];

	for(int i=0; i<filas; i++){

		m[i]=new char [columnas];

	}

	limpiar(m,filas);

	imprimir(m, filas);

	cout << "\nDame un punto ";
	cin >> x >> y;

	cout << "\nDame una longitud ";
	cin >> longitud;


	dibujarcuadrado( m, x, y, longitud, filas);	

	imprimir(m, filas);
	
	cout << "\n\n\n";
 
	rotar(m, columnas);

	imprimir(m, filas);

	for(int j=0;j<filas;j++){

		delete[] m[j];

	}

	delete[] m;

}


