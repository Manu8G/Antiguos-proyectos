#include<iostream>

using namespace std;


struct Tiempo{

	int horas;
	int minutos;
	int segundos;

};

int convertirASegundos(Tiempo obj1){

	int suma;
	
	suma=obj1.horas*3600;
	suma=suma+obj1.minutos*60;
	suma=suma+obj1.segundos ;

	return suma;

}

bool esPosterior(Tiempo obj1, Tiempo obj2){

	return (convertirASegundos(obj1)>convertirASegundos(obj2));

}

Tiempo obtenerNuevoTiempo(Tiempo obj1, int numero){

	Tiempo obj2;

	int variable;

	variable=numero+convertirASegundos(obj1);

	obj2.segundos=variable%60;
	variable=variable/60;	
	obj2.minutos=variable%60;
	variable=variable/60;

	if(variable>23){
		while(variable>23){

			variable=variable-24;
			variable=variable%23;	
			obj2.horas=variable;

		}
	}else{
	
	variable=variable%23;
	obj2.horas=variable;

	}

	return obj2;

}




int main(){

	Tiempo objeto1;
	Tiempo objeto2;
	Tiempo objeto3;
	int variable;
	
	cout << "\nPrimer tiempo: \n";

	do{
		cout << "\nIntroduzca los segundos entre 0 y 59: ";
		cin >> objeto1.segundos;

	}while(objeto1.segundos>59 || objeto1.segundos<0);

	do{

		cout << "\nIntroduzca los minutos entre 0 y 59: ";
		cin >> objeto1.minutos;

	}while(objeto1.minutos>59 || objeto1.segundos<0);

	do{

		cout << "\nIntroduzca las horas entre 0 y 23: ";
		cin >> objeto1.horas;

	}while(objeto1.horas<0 || objeto1.horas>23);


	cout << "\nIntroduzca el tiempo a sumar: ";
	cin >> variable;

	objeto3=obtenerNuevoTiempo(objeto1, variable);	
	
	cout << "\nEste es el primer tiempo con el aumento: " << objeto3.horas << " horas " << objeto3.minutos << " minutos " << objeto3.segundos << " segundos ";
 	
	cout << "\nSegundo tiempo:\n ";

	do{
		cout << "\nIntroduzca los segundos entre 0 y 59: ";
		cin >> objeto2.segundos;

	}while(objeto2.segundos>59 || objeto2.segundos<0);

	do{

		cout << "\nIntroduzca los minutos entre 0 y 59: ";
		cin >> objeto2.minutos;

	}while(objeto2.minutos>59 || objeto2.segundos<0);

	do{

		cout << "\nIntroduzca las horas entre 0 y 23: ";
		cin >> objeto2.horas;

	}while(objeto2.horas<0 || objeto2.horas>23);


	cout << "\nIntroduzca el tiempo a sumar: ";
	cin >> variable;

	
	objeto3=obtenerNuevoTiempo(objeto2, variable);

	cout << "\nEste es el primer tiempo con el aumento: " << objeto3.horas << " horas " << objeto3.minutos << " minutos " << objeto3.segundos << " segundos ";

	cout << "\nEstos son los segundos del primer instante:\n " << convertirASegundos(objeto1);
	cout << "\nEstos son los segundos del segundo instante:\n " << convertirASegundos(objeto2);
	
	if(esPosterior){
	
		cout << "\nEl primer tiempo es mayor que el segundo\n";

	}else{

		cout << "\nEl segundo tiempo es mayor que el primero\n";

	}	

	
}



