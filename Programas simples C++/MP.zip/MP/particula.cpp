#include <iostream>
#include <cmath>
#include "miniwin.h"
#include <stdlib.h>

using namespace std;
using namespace miniwin;

const int UMBRAL = 30;
static const int MIN_X = 800;
static const int MIN_Y = 600;
static const int RADIO =  10;


class Particula{

private:

float x;
float y;
float dx;
float dy;
Color c;


public:

//Constructor por defecto
Particula (){

Color vector[5] = {AZUL, MAGENTA, ROJO, VERDE, AMARILLO};//Definir este vector en otro sitio si no.
int num = rand();
x = num%(MIN_X + 1); //Asignamos una x aleatoria entre MIN_X, que es el tamaño horizontal de la pantalla. lo mismo para y
y = num%(MIN_Y + 1);
c = vector[rand()%5]; //Se supone que inicializa el color aleatorio; 
dx = num%10;//5.0;
dy = num%10;//5.0;

}

//Constructor con parámetros
Particula ( float posicionX, float posicionY){

if( posicionX >= 0 && posicionX <= MIN_X )
x = posicionX;

if( posicionY <= 0 && posicionY <= MIN_X )
y = posicionY;

dx = 1.0;
dy = 1.0;
c = AZUL;

}


void SetPosicionX( float posicionX){

x = posicionX;

}

void SetPosicionY( float posicionY){

y = posicionY;

}

float GetPosicionX (){

	return x;
}

float GetPosicionY (){

	return y;


}

//Método calcula distancia

float Distancia(Particula particula2){

	float distancia;
	
	distancia = sqrt( pow( (x - particula2.x),2 ) + pow( (y - particula2.y),2 )   );

	return distancia;

}


bool Colision(Particula particula2){

	bool hay_colision;

	float dist = Distancia(particula2);

		hay_colision = (dist <= 2*RADIO); //Definir Umbral en el header

	return hay_colision;


}

void pinta_particula() {
   color(c);
   circulo_lleno(x,y,RADIO);
   
}

void mueve_particula() { 
   const float factor = 0.97; //velocidad a la que rebota

	x += dx;
   	y += dy;

   if (x > vancho() - RADIO) {
     dx = -dx * factor;
      x = vancho() - RADIO;
   } 
	else if (x < RADIO) {
     dx = -dx * factor;
      x = RADIO;
   } 
	else if (y > valto() - RADIO) {
      dy = -dy * factor;
      y = valto() - RADIO;
   } 
	else if (y < RADIO) {
      dy = -dy * factor;
      y = RADIO;
   }

}

//HAGAMOS AQUÍ EL CHOQUE ELÁSTICO (Siempre a 45º al principio, ya que dx lo tenemos definido igual que dy. Siempre 45 por tanto.

void ChoqueElastico( Particula &particula2){

		float aux1, aux2;

		aux1 = particula2.dx;
		aux2 = particula2.dy;		

		particula2.dx = dx;
		particula2.dy = dy;

		dx = aux1;
		dy = aux2;
}





};








int main(){

int ancho, alto, particulas;




cout <<"\nIntroduzca el ancho de la pantalla: \n";
cin >> ancho;
cout <<"\nIntroduzca el alto de la pantalla: \n";
cin >> alto;
cout <<"\nIntroduzca el numero de partículas: \n";
cin >> particulas;

vredimensiona(ancho, alto);

//Particula part;//(50.0, 50.0); 4.0, 4.0, MAGENTA ; UNA SOLA PARTICULA <-------------AQUI

Particula *vector = 0;

vector = new Particula[particulas];

while (tecla() != ESCAPE) {

		borra();
	for(int i = 0; i<particulas; i++){
		vector[i].mueve_particula();
	   	vector[i].pinta_particula();

		for(int j = 0; j< particulas && (j !=i) ; j++){

			if(vector[i].Colision(vector[j]))
				vector[i].ChoqueElastico(vector[j]);

		}
     	}
	refresca();
      espera(25);
   }
   vcierra();

return 0 ;

} 
