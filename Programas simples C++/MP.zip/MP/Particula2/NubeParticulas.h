#ifndef _NUBE_H
#define _NUBE_H

const int TAM_BLOQUE=10;

#endif 
