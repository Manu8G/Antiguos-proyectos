#include<iostream>
#include<cmath>

using namespace std;


struct Punto{

	double x;
	double y;

};

bool Esta(Punto puntito, double radio, Punto centro){

	int distancia=0;
	bool solucion=false;

	distancia=sqrt(pow(puntito.x-centro.y,2)+pow(puntito.y-centro.y,2));

	cout << "\ndistancia" << distancia;

	if(distancia < radio){
		
		solucion=true;

	}
	
	return solucion;

}



int main(){

	Punto centro;
	Punto *puntos;
	bool Estaono=false;
	int npuntos=0;
	Punto *dentro;
	float  radio=0;
	int cont=0;

	cout << "Cuantos puntos quiere: ";
	cin >> npuntos;

	puntos=new Punto [npuntos];
	dentro=new Punto [npuntos];

	cout << "Introduce las coordenadas del centro: ";
	cin >> centro.x >> centro.y;

	cout << "Introduce el radio: ";
	cin >> radio;

	cout << "Introduce las coordenadas de los puntos: ";

	for(int i=0; i<npuntos;i++){

		cin >> puntos[i].x >> puntos[i].y;
	
	}

	cout << "Comprobando cuales puntos estan dentro del circulo: ";

	for(int j=0; j<npuntos; j++){

		Estaono=Esta(puntos[j], radio, centro);
	

		if(Estaono==true){
		
			dentro[cont]=puntos[j];
			cont++;
			Estaono=false;

		}

	}

	for(int g=0; g<cont; g++){

		cout << "\nEsta es la coordenada x e y: " << dentro[g].x << " " << dentro[g].y;

	}

	return 0;

}

