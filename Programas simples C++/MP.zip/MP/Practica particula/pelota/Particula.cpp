#include<iostream>
#include <cmath>
#include "miniwin.h"
#include "definiciones.h"
#include <stdlib.h>

using namespace miniwin;
using namespace std;

const int RADIO = 20;

class Particula{

	private:
	
		float x; 
		float y;
		float dx;
		float dy;
		Color c;

	public:

		Particula(){ 

			Color colores[7]={AZUL, BLANCO, MAGENTA, CYAN, ROJO, VERDE, AMARILLO};
			int randoms=rand();
			x = randoms%(MIN_X + 1); //MAS 1 para q no sea cero
			y = randoms%(MIN_Y + 1);
			c = colores[rand()%7];  //Color aleatorio
			dx = (randoms%10 + 1);		
			dy = (randoms%10 + 1);

		}

		Particula(float X, float Y){ // Lo llama cuando se pasa las cosas tipo p3(4 455)

			if(X>=0 && X<=MIN_X ){

				x=X;

			}

			if(Y<=0 && Y<=MIN_X){

				y=Y;

			}

			dx = 1.0;
			dy = 1.0;
			c = ROJO;

		}

		void setX(float X){

			x=X;

		}

		void setY(float Y){

			y=Y;

		}

		float getX() const{

			return x;
		}

		float getY () const{

			return y;

		}


		void pinta_pelota() {
			
			color(c);
			circulo_lleno(x, y, RADIO);
   
		}


		void mueve_pelota(int posicionx, int posiciony) {

			const float factor = 0.97;
			x += dx;
			y += dy;
			
			if (x > posicionx - RADIO) {
     				
				dx = -dx * factor;
      				x = posicionx - RADIO;
   
			}else if (x < RADIO) {
     
				dx = -dx * factor;
				x = RADIO;
   
			}else if (y > posiciony - RADIO) {
      
				dy = -dy * factor;
				y = posiciony - RADIO;

			}else if (y < RADIO) {
      
				dy = -dy * factor;
				y = RADIO;
   
			}
  			
		}

		float distancia(Particula P){

			float distancia=0.0;

			distancia= sqrt(pow(x-P.x,2)+pow(y-P.y,2));

			return distancia;


		}

		bool Colision(Particula P){

			float longitud=0.0;

			longitud=distancia(P);

			return(longitud<UMBRAL);
			
		}

		void Colision_natural( Particula &p2){

			float variable;
	
			variable = p2.dx;
			p2.dx = dx;
			dx = variable;


			variable = p2.dy;		
			p2.dy = dy;
			dy = variable;
		
		}
		
};


int main(){

	int particulas=0;
	int posx=0;
	int posy=0;

	cout << "\nIntroduce el tamaño max de la anchura de la ventana (mas de 800): ";
	cin >> posx;

	cout << "\nIntroduce el tamaño max de la altura de la ventana (mas de 600): "; 
	cin >> posy;

	cout << "\nIntroduce el numero de particulas: ";
	cin >> particulas;

	vredimensiona(posx, posy);

	Particula *p=0;

	p=new Particula[particulas];

	while (tecla() != ESCAPE) {

			borra();

		for(int i = 0; i<particulas; i++){

			p[i].mueve_pelota(posx, posy);
		   	p[i].pinta_pelota();

			for(int j = 0; j<particulas && (j!=i) ; j++){

				if(p[i].Colision(p[j])){

					p[i].Colision_natural(p[j]);
				
				}			
		
			}
     		}
		
		refresca();
      		espera(25);
   	}

	vcierra();

	delete [] p;

	return 0;	

}



