#ifndef _DEFINICIONES_H
#define _DEFINICIONES_H


const int UMBRAL=33;
const int MIN_X=800;
const int MIN_Y=600;
const float MAX_VEL=100.0;

#endif
