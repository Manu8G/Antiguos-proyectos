/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sesion3;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Observer;

/**
 *
 * @author domin
 */
public class Simulador extends Observable implements Runnable {

    private float temperatura;
    ArrayList<Observer> observadores;
    float temperaturaMinima, temperaturaMaxima;
    
    public Simulador(float tmin, float tmax){
        observadores = new ArrayList<Observer>();
        temperaturaMinima = tmin;
        temperaturaMaxima = tmax;
    }

    public void setTemperatura(float temp){
        temperatura = temp;
        notificar(temp);
    }
    
    public float getTemperatura(){
        return temperatura;
    }
    
    public float getTemperaturaMinima(){
        return temperaturaMinima;
    }
    
    public float getTemperaturaMaxima(){
        return temperaturaMaxima;
    }
    
    @Override
    public void addObserver(Observer o){
        observadores.add(o);
    }
    
    public void notificar(float temperatura){
        for (Observer o: observadores){
            o.update(this, temperatura);
        }
    }

    @Override
    public void run() {
        try {
            while (true){
                Random r = new Random();
                float temp = (float) (temperaturaMinima + r.nextFloat() * (temperaturaMaxima - temperaturaMinima));
                setTemperatura(temp);
                Thread.sleep(1000);
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(practica1sesion3.Simulador.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
}