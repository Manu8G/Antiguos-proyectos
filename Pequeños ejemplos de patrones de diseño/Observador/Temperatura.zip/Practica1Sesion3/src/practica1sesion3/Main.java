/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sesion3;

import GUI.BotonCambio;
import GUI.GraficaTemperatura;
import GUI.PantallaTemperatura;

/**
 *
 * @author domin
 */
public class Main {
    
    public static void main(String[] args){
        
        Simulador s = new Simulador(0, 100);
        
        BotonCambio b = new BotonCambio(s);
        GraficaTemperatura g = new GraficaTemperatura();
        PantallaTemperatura p = new PantallaTemperatura();

        s.addObserver(b);
        s.addObserver(g);
        s.addObserver(p);
        
        Thread t = new Thread(s);
        t.start();
    }    
}
