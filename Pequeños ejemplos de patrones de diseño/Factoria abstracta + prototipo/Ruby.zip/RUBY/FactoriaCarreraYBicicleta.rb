public
class FactoriaCarreraYBicicleta

	def initialize()

		# Not yet implemented
	end
end
