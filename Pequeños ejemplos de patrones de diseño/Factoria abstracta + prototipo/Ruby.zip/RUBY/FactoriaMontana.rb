require('./FactoriaCarreraYBicicleta.rb');

public
class FactoriaMontana < FactoriaCarreraYBicicleta

	def initialize()

		# Not yet implemented
	end
end
