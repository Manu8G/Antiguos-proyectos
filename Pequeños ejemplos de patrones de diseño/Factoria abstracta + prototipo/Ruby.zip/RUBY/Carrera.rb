public
class Carrera

	public
	def clone()
		# Not yet implemented
	end

	def initialize()

		# Not yet implemented
	end
end
