require('./Bicicleta.rb');

public
class BicicletaCarretera < Bicicleta

	public
	def clone()
		# Not yet implemented
	end

	def initialize()

		# Not yet implemented
	end
end
