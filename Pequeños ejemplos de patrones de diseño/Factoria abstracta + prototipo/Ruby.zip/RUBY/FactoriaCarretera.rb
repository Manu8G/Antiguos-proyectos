require('./FactoriaCarreraYBicicleta.rb');

public
class FactoriaCarretera < FactoriaCarreraYBicicleta

	def initialize()

		# Not yet implemented
	end
end
