public
class Cliente

	def initialize()

		# Not yet implemented
	end
end
