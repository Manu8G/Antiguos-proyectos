public class BicicletaMontana extends Bicicleta {
    
    public BicicletaMontana(String n){
            super(n);
    }
        
}