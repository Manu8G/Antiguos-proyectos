
import java.util.Random;

public class Cliente {
    public static void main(String[] args) {
       Random random;   
       random=new Random();
       int aux=random.nextInt(2);
       FactoriaCarreraYBicicleta factoria1;
       if(aux==1){
           factoria1=new FactoriaCarretera();
       }else{
           factoria1=new FactoriaMontana();
       }

       aux=random.nextInt(2);
       FactoriaCarreraYBicicleta factoria2;
       if(aux==1){
           factoria2=new FactoriaCarretera();
       }else{
           factoria2=new FactoriaMontana();
       }
       aux=random.nextInt(10);
       Carrera car1=factoria1.crearCarrera(aux);
       Carrera car2=factoria2.crearCarrera(aux);
       car1.iniciarCarrera(factoria1);
       car2.iniciarCarrera(factoria2);
    }
}