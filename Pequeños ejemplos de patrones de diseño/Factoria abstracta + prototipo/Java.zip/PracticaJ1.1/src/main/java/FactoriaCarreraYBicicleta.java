public interface FactoriaCarreraYBicicleta {

	Bicicleta crearBicicleta(String aux);

	Carrera crearCarrera(int numBicis);
        
}