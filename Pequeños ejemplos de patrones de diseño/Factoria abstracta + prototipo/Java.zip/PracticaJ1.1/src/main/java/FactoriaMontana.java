
import java.util.Random;

public class FactoriaMontana implements FactoriaCarreraYBicicleta {
    CarreraMontana car;
    
	public BicicletaMontana crearBicicleta(String aux) {
            BicicletaMontana bici=new BicicletaMontana(aux);
            return bici;
	}

	public CarreraMontana crearCarrera(int numBicis) {
         car=new CarreraMontana(numBicis);   
         return car;
	}
        
}