
import java.util.ArrayList;

public abstract class Carrera {

	protected ArrayList<Bicicleta> bicicletas;
        public int NumeroBicis;
        
        public Carrera(int n){
            NumeroBicis=n;
            bicicletas=new ArrayList<Bicicleta>();
        }
        
        public int getNumBicis(){
            return NumeroBicis;
        }
        public abstract void iniciarCarrera(FactoriaCarreraYBicicleta factoria);
        
        public abstract void retirarBicis(int tiempo);
        
}