
import java.util.Random;

public class CarreraMontana extends Carrera{

    public CarreraMontana(int n){
        super(n);
    }
    
    public void iniciarCarrera(FactoriaCarreraYBicicleta factoria){
        for(int i=0; i<NumeroBicis; i++){
            String a="Bicicleta-num-"+i;  
            bicicletas.add(factoria.crearBicicleta(a));
        }
        Random random;   
        random=new Random();
        int aux=random.nextInt(2);
        retirarBicis(aux);
        for(int i=0; i<NumeroBicis; i++){
            bicicletas.get(i).start();
        }  
    }
    public void retirarBicis(int tiempo){
        int num=NumeroBicis;
        num=(int) (num*0.2);
        for(int i=0; i<num; i++){
                bicicletas.get(i).setMUERTE(tiempo);
        }
    }
}