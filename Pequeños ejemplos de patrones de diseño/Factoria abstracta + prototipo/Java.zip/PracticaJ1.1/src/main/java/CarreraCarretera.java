
import java.util.Random;

public class CarreraCarretera extends Carrera {
    
    public CarreraCarretera(int n){
        super(n);
    }
    @Override
    public void iniciarCarrera(FactoriaCarreraYBicicleta factoria){
        for(int i=0; i<NumeroBicis; i++){
            String a="Bicicleta-num-"+i;
            bicicletas.add(factoria.crearBicicleta(a));
        }
        Random random;   
       random=new Random();
       int aux=random.nextInt(2);
        retirarBicis(aux);
        for(int i=0; i<NumeroBicis; i++){
            bicicletas.get(i).start();
        }        
    }
    
    public void retirarBicis(int tiempo){
        int num=NumeroBicis;
        num=(int) (num*0.1);
        for(int i=0; i<num; i++){
                bicicletas.get(i).setMUERTE(tiempo);
        }
    }
}