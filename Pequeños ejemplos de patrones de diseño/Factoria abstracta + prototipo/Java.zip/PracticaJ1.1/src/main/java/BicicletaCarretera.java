public class BicicletaCarretera extends Bicicleta {
    
    public BicicletaCarretera(String n){
            super(n);
    }
        
}