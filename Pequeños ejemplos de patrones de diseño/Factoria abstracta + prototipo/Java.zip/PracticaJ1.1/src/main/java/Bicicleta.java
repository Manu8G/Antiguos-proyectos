public abstract class Bicicleta extends Thread{
        protected static int MINUTO=60;
	protected String identificador;
        protected int MUERTE=60;

        public Bicicleta(String n){
            identificador=n;
        }
        public void setMUERTE(int muerte){
            MUERTE=muerte;
        }
        public String getIden(){
            return identificador;
        }
        @Override
        public void run(){
            boolean muerte=false;
            for(int i=0; i<=MINUTO && !muerte; i++){
                try{
                    System.out.println(identificador+"segundo "+i);
                    Thread.sleep(1);
                    if(i==MINUTO){
                        System.out.println("La bicicleta "+ identificador + " ha terminado la carrera en el segundo ");
                        muerte=true;
                        super.interrupt(); //join
                    }else if(i==MUERTE){
                        System.out.println("La bicicleta se ha retirado de la carrera en el segundo "+i);
                        muerte=true;
                        super.interrupt();
                    }
                }catch(InterruptedException e){
                    System.out.println("La bicicleta "+ identificador+" termina la carrera");
                }
            }
        }
}