
import java.util.Random;

public class FactoriaCarretera implements FactoriaCarreraYBicicleta {
      
    CarreraCarretera car;

    public BicicletaCarretera crearBicicleta(String aux) {
        BicicletaCarretera bici=new BicicletaCarretera(aux);
        /*System.out.println("AAA--"+aux+"---AAA");
        System.out.println("BBB--"+bici.getIden()+"---BBB");*/
        return bici;
    }

    public CarreraCarretera crearCarrera(int numBicis) {
         car=new CarreraCarretera(numBicis);   
         return car;
    }

}