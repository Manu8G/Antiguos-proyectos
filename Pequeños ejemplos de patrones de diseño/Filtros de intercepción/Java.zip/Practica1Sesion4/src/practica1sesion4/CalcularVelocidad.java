/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sesion4;

/**
 *
 * @author domin
 */
public class CalcularVelocidad implements Filtro {
    
    int incrementoVelocidad;
    
    @Override
    public double ejecutar (double revoluciones, EstadoMotor estadoMotor){
        
        if (estadoMotor == EstadoMotor.acelerando){
            incrementoVelocidad = 100;
        } else if (estadoMotor == EstadoMotor.frenando){
            incrementoVelocidad = -100;
        } else if (estadoMotor == EstadoMotor.apagado || estadoMotor == EstadoMotor.encendido){
            incrementoVelocidad = 0;
        }
        
        return (revoluciones + incrementoVelocidad);
    }
}
