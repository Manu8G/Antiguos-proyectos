/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sesion4;

/**
 *
 * @author domin
 */
public class RepercutirRozamiento implements Filtro {

    @Override
    public double ejecutar(double revoluciones, EstadoMotor estadoMotor) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
