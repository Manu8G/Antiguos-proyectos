/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sesion4;

import GUI.PanelBotones;

/**
 *
 * @author domin
 */
public class Practica1Sesion4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            PanelBotones panel = new PanelBotones();
    }
    
}
