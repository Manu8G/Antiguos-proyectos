/*
 * VisitantePrecio.cpp
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */


#include "VisitantePrecio.h"
#include "Disco.h"
#include "Tarjeta.h"
#include "Bus.h"

VisitantePrecio :: VisitantePrecio(){
	precioTotal = 0;
}

void VisitantePrecio :: visitarDisco (Disco & d){
	precioTotal += d.getPrecio();
}

void VisitantePrecio :: visitarTarjeta (Tarjeta & t){
	precioTotal += t.getPrecio();
}

void VisitantePrecio :: visitarBus (Bus & b){
	precioTotal += b.getPrecio();
}

double VisitantePrecio :: getPrecio(){
	return precioTotal;
}

