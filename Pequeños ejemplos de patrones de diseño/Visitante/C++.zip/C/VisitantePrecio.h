/*
 * VisitantePrecio.h
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */

#ifndef VISITANTEPRECIO_H_
#define VISITANTEPRECIO_H_

#include "VisitanteEquipo.h"
/*#include "Disco.h"
#include "Tarjeta.h"
#include "Bus.h"*/

class Disco;
class Tarjeta;
class Bus;

class VisitantePrecio : public VisitanteEquipo {
private:
	double precioTotal;

public:
	VisitantePrecio ();

	void visitarDisco (Disco & d);
	void visitarTarjeta (Tarjeta & t);
	void visitarBus (Bus & b);

	double getPrecio();
};


#endif /* VISITANTEPRECIO_H_ */
