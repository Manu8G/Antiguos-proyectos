/*
 * Bus.h
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */

#ifndef BUS_H_
#define BUS_H_

#include "ComponenteEquipo.h"

class Bus : public ComponenteEquipo {
private:
	char * nombre;
	double precio;

public:
	Bus(char *, double);

	double getPrecio();
	char * getNombre();

	void aceptar(VisitanteEquipo& ve);
};



#endif /* BUS_H_ */
