/*
 * Equipo.h
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */

#ifndef EQUIPO_H_
#define EQUIPO_H_

//#include "ComponenteEquipo.h"
class ComponenteEquipo;
#include <vector>

class Equipo {
private:
	char * nombre;
	std::vector<ComponenteEquipo*> componentes;

public:
	Equipo (char * n);

	char * getNombre();
	void anadirComponente(ComponenteEquipo & ce);
	ComponenteEquipo & obtenerComponente(int indice);
	int numeroComponentes();
};



#endif /* EQUIPO_H_ */
