/*
 * Tarjeta.h
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */

#ifndef TARJETA_H_
#define TARJETA_H_

#include "ComponenteEquipo.h"
class VisitanteEquipo;

class Tarjeta : public ComponenteEquipo {
private:
	char * nombre;
	double precio;
public:
	Tarjeta (char *, double);

	double getPrecio();
	char * getNombre();

	void aceptar(VisitanteEquipo & ve);
};



#endif /* TARJETA_H_ */
