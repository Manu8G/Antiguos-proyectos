/*
 * Disco.cpp
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */

#include "Disco.h"
#include "VisitanteEquipo.h"

Disco :: Disco (char * n, double p){
	nombre = n;
	precio = p;
}

char * Disco :: getNombre(){
	return nombre;
}

double Disco :: getPrecio(){
	return precio;
}

void Disco :: aceptar(VisitanteEquipo & ve){
	ve.visitarDisco(*this);
}
