/*
 * Tarjeta.cpp
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */

#include "Tarjeta.h"
#include "VisitanteEquipo.h"

Tarjeta :: Tarjeta (char * n, double p){
	nombre = n;
	precio = p;
}

char * Tarjeta :: getNombre(){
	return nombre;
}

double Tarjeta :: getPrecio(){
	return precio;
}

void Tarjeta :: aceptar(VisitanteEquipo & ve){
	ve.visitarTarjeta(*this);
}
