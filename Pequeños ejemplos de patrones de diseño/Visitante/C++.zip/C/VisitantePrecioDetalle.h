/*
 * VisitantePrecioDetalle.h
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */

#ifndef VISITANTEPRECIODETALLE_H_
#define VISITANTEPRECIODETALLE_H_

#include "VisitanteEquipo.h"
/*class Bus;
class Disco;
class Tarjeta;*/

class VisitantePrecioDetalle : public VisitanteEquipo {
private:
	double precioComponente;
	char * nombreComponente;

public:
	//VisitantePrecioDetalle ();

	void visitarDisco (Disco & d);
	void visitarTarjeta (Tarjeta & t);
	void visitarBus (Bus & b);

	double getPrecioComponente();
	char * getNombreComponente();
};



#endif /* VISITANTEPRECIODETALLE_H_ */
