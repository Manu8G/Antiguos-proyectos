/*
 * VisitanteEquipo.h
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */

#ifndef VISITANTEEQUIPO_H_
#define VISITANTEEQUIPO_H_

class Bus;
class Disco;
class Tarjeta;


class VisitanteEquipo {
private:

public:
	virtual void visitarDisco(Disco& d) = 0;

	virtual void visitarTarjeta(Tarjeta& t) = 0;

	virtual void visitarBus(Bus& b) = 0;
};


#endif /* VISITANTEEQUIPO_H_ */
