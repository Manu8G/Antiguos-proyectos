/*
 * Bus.cpp
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */

#include "Bus.h"
#include "VisitanteEquipo.h"

Bus :: Bus (char * n, double p){
	nombre = n;
	precio = p;
}

char * Bus :: getNombre(){
	return nombre;
}

double Bus :: getPrecio(){
	return precio;
}

void Bus :: aceptar(VisitanteEquipo& ve){
	ve.visitarBus(*this);
}
