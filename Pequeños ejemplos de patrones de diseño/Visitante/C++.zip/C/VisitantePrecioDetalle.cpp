/*
 * VisitantePrecioDetalle.cpp
 *
 *  Created on: 27 feb. 2020
 *      Author: domin
 */

#include "VisitantePrecioDetalle.h"
#include "Disco.h"
#include "Tarjeta.h"
#include "Bus.h"
/*VisitantePrecioDetalle :: VisitantePrecioDetalle (){

}*/

void VisitantePrecioDetalle :: visitarDisco (Disco & d){
	nombreComponente = d.getNombre();
	precioComponente = d.getPrecio();
}

void VisitantePrecioDetalle :: visitarTarjeta (Tarjeta & t){
	nombreComponente = t.getNombre();
	precioComponente = t.getPrecio();
}

void VisitantePrecioDetalle :: visitarBus (Bus & b){
	nombreComponente = b.getNombre();
	precioComponente = b.getPrecio();
}

char * VisitantePrecioDetalle :: getNombreComponente(){
	return nombreComponente;
}

double VisitantePrecioDetalle :: getPrecioComponente(){
	return precioComponente;
}
