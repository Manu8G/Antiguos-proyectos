/*
 * Cliente.cpp
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */

#include "Bus.h"
#include "Disco.h"
#include "Tarjeta.h"
#include "VisitantePrecio.h"
#include "VisitantePrecioDetalle.h"
#include "Equipo.h"
#include <iostream>
using namespace std;

int main(){
	Bus bus("Bus 1  ", 500);
	Disco disco("Disco 1  ", 900);
	Tarjeta tarjeta("Tarjeta 1  ", 500);

	VisitantePrecio ve;
	VisitantePrecioDetalle vd;

	Equipo e1("Equipo 1");
	Equipo e2("Equipo 2");

	e1.anadirComponente(bus);
	e1.anadirComponente(tarjeta);

	for (int i = 0; i < e1.numeroComponentes(); i++){
		e1.obtenerComponente(i).aceptar(vd);
		cout << "Componente: " << vd.getNombreComponente() << endl;
		cout << "Precio    : " << vd.getPrecioComponente() << endl;
		cout << "------------------------------------------------------------" << endl;
	}

	for (int i = 0; i < e1.numeroComponentes(); i++)
		e1.obtenerComponente(i).aceptar(ve);

	cout << ve.getPrecio() << endl;

	return 0;

}
