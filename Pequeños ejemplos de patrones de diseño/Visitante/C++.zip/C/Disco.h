/*
 * Disco.h
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */

#ifndef DISCO_H_
#define DISCO_H_

#include "ComponenteEquipo.h"
class VisitanteEquipo;

class Disco : public ComponenteEquipo {
private:
	char * nombre;
	double precio;

public:
	Disco (char *, double);

	double getPrecio();
	char * getNombre();

	void aceptar(VisitanteEquipo & ve);
};



#endif /* DISCO_H_ */
