/*
 * ComponenteEquipo.h
 *
 *  Created on: 26 feb. 2020
 *      Author: domin
 */

#ifndef COMPONENTEEQUIPO_H_
#define COMPONENTEEQUIPO_H_

//#include "VisitanteEquipo.h"
class VisitanteEquipo;

class ComponenteEquipo {
protected:
	char * nombre;
	double precio;

public:
	//ComponenteEquipo();

	virtual double getPrecio() = 0;
	virtual char * getNombre() = 0;
	virtual void aceptar(VisitanteEquipo& ve) = 0;
};



#endif /* COMPONENTEEQUIPO_H_ */
