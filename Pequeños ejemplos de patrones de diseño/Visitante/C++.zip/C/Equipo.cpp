/*
 * Equipo.cpp
 *
 *  Created on: 27 feb. 2020
 *      Author: domin
 */

#include "Equipo.h"
#include "ComponenteEquipo.h"

Equipo :: Equipo (char * n){
	nombre = n;
}

char * Equipo :: getNombre(){
	return nombre;
}

void Equipo :: anadirComponente(ComponenteEquipo & ce){
	componentes.push_back(&ce);
}

ComponenteEquipo & Equipo :: obtenerComponente(int indice){
	return *componentes.at(indice);
}

int Equipo :: numeroComponentes(){
	return componentes.size();
}
